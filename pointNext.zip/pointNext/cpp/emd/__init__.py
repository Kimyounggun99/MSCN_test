from .emd import earth_mover_distance as emd

__all__ = ['emd']